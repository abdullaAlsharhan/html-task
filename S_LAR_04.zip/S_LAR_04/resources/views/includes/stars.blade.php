@php 
echo setStars($product);
@endphp