export interface Category {
  _id: string;
  name: string;
  image: string;
  productCount: number;
}
